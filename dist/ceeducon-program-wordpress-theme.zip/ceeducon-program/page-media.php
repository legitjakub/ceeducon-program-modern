<?php
if (!defined('ABSPATH')) {
    exit;
}
/**
 * Template Name: CEEDUCON Media kit
 */

get_header();

if (ceeducon_render_block_page_content()) {
    get_footer();
    return;
}

$banner_url = ceeducon_asset_url('assets/media/ceeducon-2026-official-banner.png');
$logo_url = ceeducon_asset_url('assets/ceeducon-logo-horizontal-white.png');
$partners_url = ceeducon_asset_url('assets/media/ceeducon-partner-logos-white.png');
?>

    <main id="main">
      <section class="page-hero">
        <div class="shell page-hero-grid">
          <div>
            <p class="page-crumbs"><a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'ceeducon-program'); ?></a><span>/</span><em><?php esc_html_e('Media kit', 'ceeducon-program'); ?></em></p>
            <h1><?php esc_html_e('Media resources.', 'ceeducon-program'); ?></h1>
            <p class="page-hero-note"><?php ceeducon_text('media_hero_note', 'Official {{event_title}} visual assets, press information and a direct contact for journalists and partner organisations.'); ?></p>
          </div>
          <div class="page-hero-card page-hero-card--orange">
            <span><?php esc_html_e('Media contact', 'ceeducon-program'); ?></span>
            <strong>ceeducon@dzs.cz</strong>
            <p><?php esc_html_e('Please include your outlet, deadline and the material you need.', 'ceeducon-program'); ?></p>
            <a class="btn btn--outline" href="mailto:ceeducon@dzs.cz"><?php esc_html_e('Email the team', 'ceeducon-program'); ?></a>
          </div>
        </div>
      </section>

      <?php ceeducon_render_editor_content(); ?>

      <section class="section section--paper">
        <div class="shell section-head">
          <div data-reveal>
            <p class="kicker"><?php esc_html_e('Downloads', 'ceeducon-program'); ?></p>
            <h2 class="display-2"><?php esc_html_e('Ready-to-use media assets.', 'ceeducon-program'); ?></h2>
          </div>
          <p data-reveal="2"><?php esc_html_e('Use the approved files below for editorial coverage and partner communication. Please preserve proportions, colours and clear space around the logos.', 'ceeducon-program'); ?></p>
        </div>
        <div class="shell media-kit-grid">
          <article class="media-kit-card" data-reveal>
            <img src="<?php echo esc_url($banner_url); ?>" alt="<?php echo esc_attr(ceeducon_text_value('media_banner_alt', 'Official {{event_title}} conference banner')); ?>" width="2162" height="1067" loading="lazy" decoding="async" />
            <span><?php esc_html_e('Official visual', 'ceeducon-program'); ?></span>
            <h3><?php esc_html_e('Conference banner', 'ceeducon-program'); ?></h3>
            <p><?php ceeducon_text('media_banner_text', 'High-resolution {{event_title}} key visual for digital publication.'); ?></p>
            <a class="btn btn--outline" href="<?php echo esc_url($banner_url); ?>" download><?php esc_html_e('Download PNG', 'ceeducon-program'); ?></a>
          </article>
          <article class="media-kit-card media-kit-card--dark" data-reveal="2">
            <img src="<?php echo esc_url($logo_url); ?>" alt="CEEDUCON" width="1182" height="604" loading="lazy" decoding="async" />
            <span><?php esc_html_e('Logo', 'ceeducon-program'); ?></span>
            <h3><?php esc_html_e('CEEDUCON logo', 'ceeducon-program'); ?></h3>
            <p><?php esc_html_e('Horizontal conference logo prepared for light backgrounds.', 'ceeducon-program'); ?></p>
            <a class="btn btn--outline" href="<?php echo esc_url($logo_url); ?>" download><?php esc_html_e('Download PNG', 'ceeducon-program'); ?></a>
          </article>
          <article class="media-kit-card media-kit-card--dark" data-reveal="3">
            <img src="<?php echo esc_url($partners_url); ?>" alt="<?php esc_attr_e('CEEDUCON organiser and partner logos', 'ceeducon-program'); ?>" width="480" height="20" loading="lazy" decoding="async" />
            <span><?php esc_html_e('Partners', 'ceeducon-program'); ?></span>
            <h3><?php esc_html_e('Partner logo row', 'ceeducon-program'); ?></h3>
            <p><?php esc_html_e('Official organiser and partner logo row for dark backgrounds.', 'ceeducon-program'); ?></p>
            <a class="btn btn--outline" href="<?php echo esc_url($partners_url); ?>" download><?php esc_html_e('Download PNG', 'ceeducon-program'); ?></a>
          </article>
        </div>
      </section>

      <section class="section">
        <div class="shell">
          <?php /* The heading belongs outside .press-list: that list paints its
                   own background so the 1px gaps between rows read as hairlines,
                   and anything else placed inside it sits on that colour. */ ?>
          <div class="section-head">
            <div data-reveal>
              <p class="kicker"><?php esc_html_e('Press releases', 'ceeducon-program'); ?></p>
              <h2 class="display-2"><?php esc_html_e('News for media and partners.', 'ceeducon-program'); ?></h2>
            </div>
            <p data-reveal="2"><?php ceeducon_text('media_press_lead', 'The {{year}} press release archive will be published here as materials are approved by the organisers.'); ?></p>
          </div>
          <div class="press-list" data-reveal>
            <article class="press-item">
              <span><?php esc_html_e('Coming soon', 'ceeducon-program'); ?></span>
              <div>
                <h3><?php ceeducon_text('media_press_title', '{{event_title}} press releases'); ?></h3>
                <p><?php esc_html_e('Approved press releases and announcements will be published here as they become available.', 'ceeducon-program'); ?></p>
              </div>
            </article>
          </div>
        </div>
      </section>
    </main>

<?php
get_footer();

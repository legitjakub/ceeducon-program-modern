<?php
if (!defined('ABSPATH')) {
    exit;
}

$raw_youtube = trim((string) ceeducon_block_value($attributes, 'youtube', 'oad5sn8ku1c'));
$youtube_id = '';
if (preg_match('/(?:v=|youtu\.be\/|embed\/)?([A-Za-z0-9_-]{6,})/', $raw_youtube, $matches)) {
    $youtube_id = $matches[1];
}

if ($youtube_id === '') {
    return;
}

$section_class = !empty($attributes['paper']) ? 'section section--media section--paper' : 'section section--media';
$poster_url = (string) ceeducon_block_value($attributes, 'posterUrl', ceeducon_asset_url('assets/media/ceeducon-photo-plenary.jpg'));
$poster_alt = (string) ceeducon_block_value($attributes, 'posterAlt', '');
?>
<section class="<?php echo esc_attr($section_class); ?>">
  <div class="shell media-showcase">
    <div class="media-copy" data-reveal>
      <p class="kicker"><?php echo ceeducon_block_text($attributes, 'kicker'); ?></p>
      <h2 class="display-2"><?php echo ceeducon_block_html($attributes, 'title'); ?></h2>
      <p><?php echo ceeducon_block_html($attributes, 'text'); ?></p>
      <div class="media-actions">
        <?php echo ceeducon_render_block_button((string) ceeducon_block_value($attributes, 'primaryText'), (string) ceeducon_block_value($attributes, 'primaryUrl'), 'btn btn--primary'); ?>
      </div>
    </div>
    <div class="video-card" data-youtube-id="<?php echo esc_attr($youtube_id); ?>" data-video-title="<?php echo esc_attr((string) ceeducon_block_value($attributes, 'videoTitle', 'CEEDUCON atmosphere video')); ?>" data-reveal="2">
      <button class="video-card-trigger" type="button" data-video-trigger aria-label="<?php echo esc_attr((string) ceeducon_block_value($attributes, 'videoTitle', 'Play CEEDUCON atmosphere video')); ?>">
        <img src="<?php echo esc_url($poster_url); ?>" alt="<?php echo esc_attr($poster_alt); ?>" loading="lazy" decoding="async" />
        <span class="video-card-content">
          <span class="video-card-kicker"><?php echo ceeducon_block_text($attributes, 'kicker'); ?></span>
          <strong><?php echo ceeducon_block_html($attributes, 'title'); ?></strong>
          <small><?php echo ceeducon_block_html($attributes, 'text'); ?></small>
        </span>
        <span class="video-play-icon" aria-hidden="true">
          <svg viewBox="0 0 24 24"><path d="M9 7l8 5-8 5z" /></svg>
        </span>
      </button>
    </div>
  </div>
</section>

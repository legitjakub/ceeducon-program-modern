(function (blocks, element, blockEditor, components, i18n) {
  const el = element.createElement;
  const { RichText, InspectorControls, MediaUpload, MediaUploadCheck, URLInput } = blockEditor;
  const { PanelBody, TextControl, ToggleControl, Button } = components;
  const { __ } = i18n;

  blocks.registerBlockType("ceeducon/video-feature", {
    edit({ attributes, setAttributes }) {
      const onSelectPoster = (media) => {
        setAttributes({
          posterId: media.id,
          posterUrl: media.url,
          posterAlt: media.alt || media.title || "",
        });
      };

      return el(
        "section",
        { className: `section section--media ceeducon-editor-block ${attributes.paper ? "section--paper" : ""}` },
        el(
          InspectorControls,
          {},
          el(
            PanelBody,
            { title: __("Video", "ceeducon-program"), initialOpen: true },
            el(TextControl, {
              label: __("YouTube ID nebo URL", "ceeducon-program"),
              value: attributes.youtube,
              onChange: (youtube) => setAttributes({ youtube }),
              help: __("Například oad5sn8ku1c nebo celý YouTube odkaz.", "ceeducon-program"),
            }),
            el(TextControl, {
              label: __("Titulek iframe", "ceeducon-program"),
              value: attributes.videoTitle,
              onChange: (videoTitle) => setAttributes({ videoTitle }),
            })
          ),
          el(
            PanelBody,
            { title: __("Tlačítko", "ceeducon-program"), initialOpen: false },
            el(TextControl, { label: __("Text tlačítka", "ceeducon-program"), value: attributes.primaryText, onChange: (primaryText) => setAttributes({ primaryText }) }),
            el(URLInput, { label: __("URL tlačítka", "ceeducon-program"), value: attributes.primaryUrl, onChange: (primaryUrl) => setAttributes({ primaryUrl }) })
          ),
          el(
            PanelBody,
            { title: __("Vzhled", "ceeducon-program"), initialOpen: false },
            el(ToggleControl, {
              label: __("Světlé papírové pozadí", "ceeducon-program"),
              checked: attributes.paper,
              onChange: (paper) => setAttributes({ paper }),
            }),
            el(TextControl, { label: __("Alt text posteru", "ceeducon-program"), value: attributes.posterAlt, onChange: (posterAlt) => setAttributes({ posterAlt }) }),
            el(
              MediaUploadCheck,
              {},
              el(MediaUpload, {
                onSelect: onSelectPoster,
                allowedTypes: ["image"],
                value: attributes.posterId,
                render: ({ open }) => el(Button, { variant: "secondary", onClick: open }, attributes.posterUrl ? __("Změnit poster", "ceeducon-program") : __("Vybrat poster", "ceeducon-program")),
              })
            )
          )
        ),
        el(
          "div",
          { className: "shell media-showcase" },
          el(
            "div",
            { className: "media-copy" },
            el(RichText, { tagName: "p", className: "kicker", value: attributes.kicker, allowedFormats: [], onChange: (kicker) => setAttributes({ kicker }) }),
            el(RichText, { tagName: "h2", className: "display-2", value: attributes.title, allowedFormats: ["core/bold", "core/italic"], onChange: (title) => setAttributes({ title }) }),
            el(RichText, { tagName: "p", value: attributes.text, allowedFormats: ["core/bold", "core/italic"], onChange: (text) => setAttributes({ text }) }),
            el("div", { className: "media-actions" }, attributes.primaryText ? el("span", { className: "btn btn--primary" }, attributes.primaryText) : null)
          ),
          el(
            "div",
            { className: "video-card" },
            el(
              "div",
              { className: "video-card-trigger" },
              attributes.posterUrl ? el("img", { src: attributes.posterUrl, alt: attributes.posterAlt || "" }) : null,
              el(
                "span",
                { className: "video-card-content" },
                el("span", { className: "video-card-kicker" }, __("Video preview", "ceeducon-program")),
                el("strong", {}, attributes.videoTitle || __("CEEDUCON video", "ceeducon-program")),
                el("small", {}, attributes.youtube || __("Add YouTube ID in the sidebar", "ceeducon-program"))
              ),
              el("span", { className: "video-play-icon", "aria-hidden": true }, el("svg", { viewBox: "0 0 24 24" }, el("path", { d: "M9 7l8 5-8 5z" })))
            )
          )
        )
      );
    },
    save() {
      return null;
    },
  });
})(window.wp.blocks, window.wp.element, window.wp.blockEditor, window.wp.components, window.wp.i18n);
